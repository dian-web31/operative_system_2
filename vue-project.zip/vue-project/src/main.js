// src/main.js
import 'vuetify/styles';
import { VApp, VContainer, VBtn, VCard, VCardTitle, VForm, VTextField } from 'vuetify/components';
import { createApp } from 'vue';
import App from './App.vue';
import router from './router';
import store from './store';
import { createVuetify } from 'vuetify'; // Importa desde 'vuetify'
const vuetify = createVuetify({
    components: {
      VApp, VContainer, VBtn, VCard, VCardTitle, VForm, VTextField
    }
  });

createApp(App)
  .use(router)
  .use(store)
  .use(vuetify)
  .mount('#app');
