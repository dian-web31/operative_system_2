<!-- src/components/Game.vue -->
<template>
    <v-container>
      <v-card>
        <v-card-title>Videojuego: Pong</v-card-title>
        <canvas ref="gameCanvas" width="800" height="400" style="border: 1px solid black;"></canvas>
      </v-card>
    </v-container>
  </template>
  
  <script>
  export default {
    data() {
      return {
        ball: { x: 400, y: 200, vx: 2, vy: 2 },
        paddle1: { y: 150 },
        paddle2: { y: 150 },
      };
    },
    mounted() {
      this.canvas = this.$refs.gameCanvas;
      this.ctx = this.canvas.getContext('2d');
      window.addEventListener('keydown', this.handleKeyDown);
      this.gameLoop();
    },
    methods: {
      handleKeyDown(event) {
        if (event.key === 'ArrowUp') this.paddle2.y = Math.max(0, this.paddle2.y - 10);
        if (event.key === 'ArrowDown') this.paddle2.y = Math.min(300, this.paddle2.y + 10);
        if (event.key === 'w') this.paddle1.y = Math.max(0, this.paddle1.y - 10);
        if (event.key === 's') this.paddle1.y = Math.min(300, this.paddle1.y + 10);
      },
      gameLoop() {
        this.updateGame();
        this.renderGame();
        requestAnimationFrame(this.gameLoop);
      },
      updateGame() {
        // Movimiento de la pelota
        this.ball.x += this.ball.vx;
        this.ball.y += this.ball.vy;
  
        // Rebote en bordes
        if (this.ball.y <= 0 || this.ball.y >= 400) this.ball.vy *= -1;
  
        // Colisión con paletas
        if (
          (this.ball.x <= 30 && this.ball.y >= this.paddle1.y && this.ball.y <= this.paddle1.y + 100) ||
          (this.ball.x >= 770 && this.ball.y >= this.paddle2.y && this.ball.y <= this.paddle2.y + 100)
        ) {
          this.ball.vx *= -1;
        }
  
        // Reinicio en caso de gol
        if (this.ball.x <= 0 || this.ball.x >= 800) {
          this.ball = { x: 400, y: 200, vx: 2, vy: 2 };
        }
      },
      renderGame() {
        this.ctx.clearRect(0, 0, 800, 400);
  
        // Dibujar pelota
        this.ctx.fillStyle = 'white';
        this.ctx.beginPath();
        this.ctx.arc(this.ball.x, this.ball.y, 10, 0, Math.PI * 2);
        this.ctx.fill();
  
        // Dibujar paletas
        this.ctx.fillRect(20, this.paddle1.y, 10, 100);
        this.ctx.fillRect(770, this.paddle2.y, 10, 100);
      },
    },
  };
  </script>
  