<!-- src/components/Settings.vue -->
<template>
    <v-container>
      <v-card>
        <v-card-title>Configuración</v-card-title>
        <v-form>
          <v-switch v-model="settings.darkMode" label="Modo Oscuro"></v-switch>
          <v-btn @click="saveSettings">Guardar Cambios</v-btn>
        </v-form>
      </v-card>
    </v-container>
  </template>
  
  <script>
  import axios from 'axios';
  export default {
    data() {
      return {
        settings: {
          darkMode: false,
        },
      };
    },
    async created() {
      const response = await axios.get('/api/settings');
      this.settings = response.data;
    },
    methods: {
      async saveSettings() {
        await axios.post('/api/settings', this.settings);
        alert('Configuración guardada');
      },
    },
  };
  </script>
  