<!-- src/components/WebBrowser.vue -->
<template>
    <v-container>
      <v-card>
        <v-card-title>Navegador Web</v-card-title>
        <v-text-field v-model="url" label="URL"></v-text-field>
        <v-btn @click="loadPage">Ir</v-btn>
        <iframe v-if="url" :src="formattedUrl" style="width: 100%; height: 80vh; border: none;"></iframe>
      </v-card>
    </v-container>
  </template>
  
  <script>
  export default {
    data() {
      return {
        url: '',
      };
    },
    computed: {
      formattedUrl() {
        return this.url.startsWith('http') ? this.url : `https://${this.url}`;
      },
    },
    methods: {
      loadPage() {
        if (!this.url) alert('Por favor, ingresa una URL.');
      },
    },
  };
  </script>
  