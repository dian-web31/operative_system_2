<!-- src/components/Calculator.vue -->
<template>
    <v-container>
      <v-card>
        <v-card-title>Calculadora Científica</v-card-title>
        <v-text-field v-model="expression" label="Expresión"></v-text-field>
        <v-btn @click="calculate">Calcular</v-btn>
        <div>Resultado: {{ result }}</div>
      </v-card>
    </v-container>
  </template>
  
  <script>
  import { evaluate } from 'mathjs';
  export default {
    data() {
      return {
        expression: '',
        result: '',
      };
    },
    methods: {
      calculate() {
        try {
          this.result = evaluate(this.expression);
        } catch {
          this.result = 'Error en la expresión';
        }
      },
    },
  };
  </script>
  