<!-- src/components/TaskManager.vue -->
<template>
    <v-container>
      <v-card>
        <v-card-title>Administrador de Tareas</v-card-title>
        <v-list>
          <v-list-item
            v-for="task in tasks"
            :key="task.name"
          >
            <v-list-item-content>{{ task.name }}</v-list-item-content>
            <v-btn color="red" @click="endTask(task.name)">Cerrar</v-btn>
          </v-list-item>
        </v-list>
      </v-card>
    </v-container>
  </template>
  
  <script>
  export default {
    data() {
      return {
        tasks: [
          { name: 'Calculadora' },
          { name: 'Editor de Texto' },
          { name: 'Visor de Imágenes' },
        ],
      };
    },
    methods: {
      endTask(taskName) {
        this.tasks = this.tasks.filter(task => task.name !== taskName);
        alert(`Tarea "${taskName}" cerrada`);
      },
    },
  };
  </script>
  