<!-- src/components/FileManager.vue -->
<template>
    <v-container>
      <v-card>
        <v-card-title>Administrador de Archivos</v-card-title>
        <v-btn @click="loadFiles">Cargar Archivos</v-btn>
        <ul>
          <li v-for="file in files" :key="file" @click="openFile(file)">
            {{ file }}
          </li>
        </ul>
        <v-textarea v-model="fileContent" label="Contenido del archivo"></v-textarea>
        <v-btn @click="saveFile">Guardar</v-btn>
      </v-card>
    </v-container>
  </template>
  
  <script>
  import axios from 'axios';
  export default {
    data() {
      return {
        files: [],
        fileContent: '',
        selectedFile: null,
      };
    },
    methods: {
      async loadFiles() {
        const response = await axios.get('/api/files/list', {
          headers: { 'user-id': 'user1' },
        });
        this.files = response.data.files;
      },
      async openFile(file) {
        const response = await axios.get(`/api/files/read/${file}`, {
          headers: { 'user-id': 'user1' },
        });
        this.fileContent = response.data.content;
        this.selectedFile = file;
      },
      async saveFile() {
        await axios.post(
          '/api/files/create',
          { name: this.selectedFile, content: this.fileContent },
          { headers: { 'user-id': 'user1' } }
        );
        alert('Archivo guardado');
      },
    },
  };
  </script>
  