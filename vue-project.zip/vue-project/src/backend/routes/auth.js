// src/backend/routes/auth.js
const express = require('express');
const router = express.Router();
const roles = require('../models/roles');

let users = []; // Esto debería ser una base de datos en producción

// Ruta para registrar un usuario
router.post('/register', (req, res) => {
  const { username, password, role } = req.body;

  if (!roles[role]) {
    return res.status(400).json({ error: 'Rol no válido' });
  }

  if (users.find(u => u.username === username)) {
    return res.status(400).json({ error: 'El usuario ya existe' });
  }

  // Guardar el usuario con su rol
  users.push({ username, password, role });
  res.status(201).json({ message: 'Usuario registrado correctamente' });
});

// Ruta para login (verificar el usuario y el rol)
router.post('/login', (req, res) => {
  const { username, password } = req.body;
  const user = users.find(u => u.username === username && u.password === password);

  if (!user) {
    return res.status(401).json({ error: 'Credenciales incorrectas' });
  }

  res.json({
    message: 'Login exitoso',
    user: { username: user.username, role: user.role }
  });
});

module.exports = router;
