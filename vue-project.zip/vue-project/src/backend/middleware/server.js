// src/backend/server.js
const express = require('express');
const path = require('path');
const cors = require('cors');
const bodyParser = require('body-parser');
const authRoutes = require('./routes/auth');
const chatbotRoutes = require('./routes/chatbot');
const fileSystemRoutes = require('./routes/fileSystem');
const mediaRoutes = require('./routes/media');
const protectedRoutes = require('./routes/protected');
const settingsRoutes = require('./routes/settings');

const app = express();
const port = process.env.PORT || 3000;

// Middlewares
app.use(cors());
app.use(bodyParser.json());

// Rutas de la API
app.use('/api/auth', authRoutes);
app.use('/api/chatbot', chatbotRoutes);
app.use('/api/file-system', fileSystemRoutes);
app.use('/api/media', mediaRoutes);
app.use('/api/protected', protectedRoutes);
app.use('/api/settings', settingsRoutes);

// Servir los archivos estáticos del frontend
app.use(express.static(path.join(__dirname, '../../frontend/dist')));

// Redirigir todas las otras solicitudes a la aplicación Vue.js (SPA)
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../../frontend/dist/index.html'));
});

// Iniciar el servidor
app.listen(port, () => {
  console.log(`Servidor corriendo en http://localhost:${port}`);
});
