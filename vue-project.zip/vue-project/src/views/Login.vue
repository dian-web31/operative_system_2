<!-- src/views/Login.vue -->
<template>
    <v-form @submit.prevent="login">
      <v-text-field v-model="username" label="Username" required></v-text-field>
      <v-text-field v-model="password" label="Password" type="password" required></v-text-field>
      <v-btn type="submit">Iniciar Sesión</v-btn>
    </v-form>
  </template>
  
  <script>
  import axios from 'axios';
  
  export default {
    data() {
      return {
        username: '',
        password: '',
      };
    },
    methods: {
      async login() {
        try {
          const response = await axios.post('api/auth/login', {
            username: this.username,
            password: this.password
          });
          
          const userRole = response.data.user.role;
          
          // Guardar el rol del usuario en el localStorage o en el estado global
          localStorage.setItem('user-role', userRole);
  
          if (userRole === 'admin') {
            this.$router.push('/admin-dashboard');  // Redirigir a área de admin
          } else if (userRole === 'editor') {
            this.$router.push('/editor-dashboard');  // Redirigir a área de editor
          } else {
            this.$router.push('/viewer-dashboard');  // Redirigir a área de viewer
          }
        } catch (error) {
          console.error('Login error:', error);
        }
      }
    }
  };
  </script>
  