<!-- src/views/Desktop.vue -->
<template>
    <v-container>
      <v-row>
        <v-col
          v-for="(app, index) in apps"
          :key="index"
          cols="2"
        >
          <v-card @click="openApp(app.name)">
            <v-img :src="app.icon" height="100"></v-img>
            <v-card-title>{{ app.name }}</v-card-title>
          </v-card>
        </v-col>
      </v-row>
    </v-container>
  </template>
  
  <script>
  export default {
    data() {
      return {
        apps: [
          { name: 'Calculadora', icon: '/icons/calculator.png' },
          { name: 'File System', icon: '/icons/files.png' },
          { name: 'Editor de textos', icon: '/icons/editor.png' },
          { name: 'Visor de imágenes', icon: '/icons/viewer.png' },
          { name: 'Reproductor de música', icon: '/icons/music.png' },
          { name: 'Videojuego', icon: '/icons/game.png' },
          { name: 'Navegador Web', icon: '/icons/browser.png' },
          { name: 'Chatbot', icon: '/icons/chatbot.png' },
        ],
      };
    },
    methods: {
        openApp(appName) {
            const role = localStorage.getItem('user-role');
            const permissions = {
            'Calculadora': 'all',
            'File System': 'file-system',
            'Editor de textos': 'text-editor',
            // Otros permisos...
            };

            if (permissions[appName] && roles[role].includes(permissions[appName])) {
            this.$router.push(`/apps/${appName}`);
            } else {
            alert('Acceso denegado.');
            }
        },
    },
  };
  </script>
  