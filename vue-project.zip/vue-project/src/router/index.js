// src/router/index.js
import { createRouter, createWebHistory } from 'vue-router';
import Login from '../views/Login.vue';
import Desktop from '../views/Desktop.vue';
import Home from '../views/Home.vue';
import Settings from '../components/Settings.vue';
import Calculator from '../components/Calculator.vue';

const routes = [
  { path: '/', component: Login },
  { path: '/desktop', component: Desktop },
  { path: '/home', component: Home },
  { path: '/settings', component: Settings },
  { path: '/apps/Calculadora', component: Calculator },
  // Más rutas...
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});

export default router;
